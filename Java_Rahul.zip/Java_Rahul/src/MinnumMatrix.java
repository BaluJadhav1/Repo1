
public class MinnumMatrix {

	public static void main(String[] args) {
		int a[][]= {{2,5,4},{7,6,5},{1,8,9}};
		int min=a[0][0];
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				if(a[i][j]<min)
				{
					min=a[i][j];	
				}
				
			}
		}
		System.out.println(min);

	}

}
