import java.util.ArrayList;

public class Araylistex {

	public static void main(String[] args) {
		ArrayList<String> a=new ArrayList<String>();
		a.add("Balu");
		a.add("Balu");
		System.out.println(a);
		a.add(0, "welcome");
		System.out.println(a);
		a.get(1);
		System.out.println(a.contains("test"));
		System.out.println(a);
		//a.remove("Balu");
		System.out.println(a);
		System.out.println(a.contains("welcome"));
		System.out.println(a.size());
		System.out.println(a.isEmpty());

	}

}
 