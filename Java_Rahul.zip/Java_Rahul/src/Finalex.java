
public class Finalex {

	public static void main(String[] args) {
		int a =5;
		 //int a=6;
		System.out.println(a);

	}

}
