
public class ArrayDemo {

	public static void main(String[] args) {
		int a[]=new int[4];
		a[0]=12;
		a[1]=14;
		a[2]=20;
		a[3]=22;				
		for(int i=0; i<=a.length-1;i++)
		{
		System.out.println(a[i]);
		}
		int b[]= {1,2,4,6,8,7};
		for(int j=0; j<=b.length-1;j++)
		{
		System.out.println(b[j]);
		System.out.println("Welcome githut");
		System.out.println("Welcome githut");
		System.out.println("Welcome githut xxxx person");

	}
	
}
}
