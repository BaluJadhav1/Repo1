import java.util.TreeSet;

public class Treesetex {

	public static void main(String[] args) {
		TreeSet<String> tr=new TreeSet<String>();
		tr.add("JAVA");
		tr.add("JAVA");
		System.out.println(tr);

	}

}
