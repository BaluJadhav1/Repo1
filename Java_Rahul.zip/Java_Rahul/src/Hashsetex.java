import java.util.HashSet;
import java.util.Iterator;

public class Hashsetex {

	public static void main(String[] args) {
		HashSet<String> hs=new HashSet<String>();
		hs.add("USA");
		hs.add("UK");
		hs.add("INDIA");
		hs.add("UK");
		//hs.remove("UK");
		//System.out.println(hs.size());
		System.out.println(hs);
		Iterator<String> i=hs.iterator();
		System.out.println(i.next());
		System.out.println(i.next());
		System.out.println(i.next());
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
				

	}

}
