
public class MinnumcolnMatrix {

	public static void main(String[] args) {
		int a[][]= {{4,7,5},{5,7,8},{9,6,3}};
		int min=a[0][0];
		int mincoln=0;
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				if(a[i][j]<min)
				{
					min=a[i][j];
					 mincoln = j;
				}
				
			}
		}
		int max=a[0][mincoln];
		int k=0;
		while(k<3)
		{
			if(a[k][mincoln]>max)
			{
				max=a[k][mincoln];
			}
			k++;
		}
		System.out.println(max);
	}

}
