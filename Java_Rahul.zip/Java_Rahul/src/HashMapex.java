import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
 public class HashMapex {

	public static void main(String[] args) {
		HashMap<Integer, String> hm=new HashMap<Integer, String>();
		hm.put(0, "India");
		hm.put(2, "UK");
		hm.put(45, "China");
		hm.put(1, "USA");
		System.out.println(hm);
		System.out.println(hm.get(45 ));
		Set sn= hm.entrySet();
		Iterator<String> it=sn.iterator();
		while(it.hasNext())
		{
			Map mp=it.next();
			System.out.println(mp.getKey());
		}

	}

}
